<?php $statuses  = \App\Status::all(); ?>
<?php $roles  = \App\Role::all(); ?>
<?php $documents  = \App\Document::all(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(!Auth::check()): ?>
      <div class="alert alert-danger" role="alert">

        <h2 class="alert-heading">Please login</h2>
        <h4 >Some features require being logged in to the system.</h4>
        </div>
         <?php else: ?>

<div class="row">
  <div class="col-xs-4">
    <h1>CREATE TRANSMITTAL </h1>
  </div>
  <div class="status_list">
    <form class="" action="/transmittals" method="post">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('post')); ?>

    <table class="table">

      <tr>
          Document Statuses:
      </tr>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($status->id !== 1): ?>
      <tr><td>

         <?php echo e($status->id); ?> : <?php echo e($status->name); ?></td> </tr>
         <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </table>

  </div>
  <div >
    <label for="transmittal">Transmittal Number</label>
  <input  type="text" name="number" value="">
</div>
<div>
    <label for="title">Transmittal Title</label>
  <input type="text" name="title" value="">

  </div>
</div>
<hr style="color:transparent">
<input name="documents" value="">
    <table class="table table-bordered table-striped" style="font-size:0.8em">
      <thead>
        <tr>

          <th>Sel</th>
          <th>Number</th>
          <th>Title</th>
          <th>Revision</th>
          <th>Rev. Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <td><input type="checkbox" name="documents[]" value="<?php echo e($document->id); ?>"></td>
            <td><?php echo e($document->full_number); ?></td>
            <td><?php echo e($document->title); ?></td>
            <td><?php echo e($document->revision); ?></td>
            <td><?php echo e($document->revision_date); ?></td>

            <td>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if( $document->status_id===
           $status->id): ?> <?php echo e($status->name); ?>

          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


          </td>





          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


        </tbody>
      </table>
</input>
<?php endif; ?>
<div class="col-xs-3 col-xs-offset-8  col-md-2 col-md-offset-10"> <input type="submit"class="btn btn-success btn-lg" name="trn-"title="Create Transmittal" value="Generate Transmittal" ><a href="#" style="text-decoration:none; color:white" >Generate Transmittal</a></button></div>

</form>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>