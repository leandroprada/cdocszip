<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php if(!Auth::check()): ?>

    <div class="alert alert-danger" role="alert">
        <h2 class="alert-heading">Please login</h2>
        <h4 >Some features require being logged in to the system.</h4>
        </div>
         <?php else: ?>
    <h1><?php echo e($document->name); ?></h1>

    <div class="row">
      <div class="col-xs-7 col-xs-offset-5"><h3>Document for Project - <?php echo e($document->project->code); ?> - <?php echo e($document->project->name); ?></h3></div>
      <div class="col-md-8">
        <h2><?php echo e($document->full_number); ?></h2>
        <p>Title: <?php echo e($document->title); ?> </p>

        <p>Rev:     <?php echo e($document->revision); ?> - Date:
        <?php echo e($document->revision_date); ?></p>


          <h3>Other Data</h3>

          <p>Area - <?php echo e($document->area->name); ?></p>

          <p>Discipline - <?php echo e($document->discipline->name); ?></p>

          <p>Division - <?php echo e($document->division->name); ?></p>


      </div>



    </div>
<?php endif; ?>
<a href="<?php echo e(url('/documents')); ?>">Go back to List</a>

  </div>

<?php $__env->stopSection(); ?>



<!-- <?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.js"></script>
<?php $__env->stopSection(); ?> -->

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>