<?php $statuses  = \App\Status::all(); ?>
<?php $roles  = \App\Role::all(); ?>
<?php $documents  = \App\Document::all(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php if(!Auth::check()): ?>

    <div class="alert alert-danger" role="alert">
        <h2 class="alert-heading">Please login</h2>
        <h4 >Some features require being logged in to the system.</h4>
        </div>
         <?php else: ?>

<div class="row">
  <div class="col-xs-4">
    <h1>DL - Document List </h1>
  </div>
  <div class="status_list">
    <table class="table">
      <tr>
          Document Statuses:
      </tr>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($status->id !== 1): ?>
      <tr><td>

         <?php echo e($status->id); ?> : <?php echo e($status->name); ?></td> </tr>
         <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </table>

  </div>
<div class="col-xs-3 col-xs-offset-8  col-md-2 col-md-offset-10"> <button type="button"class="btn btn-success btn-lg" name="button"  ><a href="/documents/create" style="text-decoration:none; color:white" >New Document</a></button></div>
</div>
<hr style="color:transparent">
    <table class="table table-bordered table-striped" style="font-size:0.8em">
      <thead>
        <tr>
          <th>Number</th>
          <th>Title</th>
          <th>Revision</th>
          <th>Rev. Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <td><?php echo e($document->full_number); ?></td>
            <td><?php echo e($document->title); ?></td>
            <td><?php echo e($document->revision); ?></td>
            <td><?php echo e($document->revision_date); ?></td>

            <td>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if( $document->status_id===
           $status->id): ?> <?php echo e($status->name); ?>

          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


          </td>
            <?php if(Auth::user()->role_id === 2): ?>
            <td style="text-align:center">
              <a href="/documents/<?php echo e($document->id); ?>/edit" title="Edit" ><button type="button"class="btn btn-outline btn-xs" style="padding-left:5px;" name="button"id="btn_index_docs_edit"> <span class="ion-compose" style="font-size:2.2em"></span></button></a>

              <a href="/documents/<?php echo e($document->id); ?>/version"  title="Version" ><button type="button"class="btn btn-outline btn-xs" style="padding-left:5px;" name="button"id="btn_index_docs_version" ><span class="ion-ios-copy-outline" style="font-size:2.2em"></span></button></a>
              <a href="/documents/<?php echo e($document->id); ?>/" title="Details" ><button type="button"class="btn btn-outline btn-xs" style="padding-left:5px;" name="button" id="btn_index_docs_details"><span class="ion-ios-list-outline" style="font-size:2.2em"></span></button></a>
        <form action="/documents/<?php echo e($document->id); ?>" method="post" style="display: inline-block;">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('delete')); ?>

              <button type="submit" name="Borrar"title="Delete" id="btn_index_docs_delete" value="DELETE" class="btn btn-danger btn-xs" style="padding-left:5px;" style="display: inline-block; " ><span class="ion-close" style="font-size:2.2em"></span></button>
              </form>
            </td>

              <?php endif; ?>



          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
      </table>

<?php endif; ?>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>