<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="/uploadfile" method="post" class="form-horizontal" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
      <label for="file-upload" class="custom-file-upload btn">
      <span class="ion-upload" style="font-size:2em"></span>  Upload a file
      </label>
      <input  id="file-upload" type="file"/>
      </div>

      <div class="form-group">
        <input type="submit" name="Upload" class="btn-lg btn-primary">
      </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>