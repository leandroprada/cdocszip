<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php if(!Auth::check()): ?>

    <div class="alert alert-danger" role="alert">
        <h2 class="alert-heading">Please login</h2>
        <h4 >Some features require being logged in to the system.</h4>
        </div>
         <?php else: ?>
    <form action="/transmittals" method="post" class="form-horizontal">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('post')); ?>


      <div class="form-group">
        <label for="number">Transmittal Number</label>
        <input type="text" name="number" value="<?php echo e(old('number')); ?>" placeholder="0001" class="form-control">
      </div>

      <div class="form-group">
        <label for="title">Title</label>
        <input type="text" name="title" value="<?php echo e(old('title')); ?>" placeholder="Type Document Title" class="form-control">
      </div>

      <div class="form-group">
        <label for="discipline_id">Discipline</label>
        <select name="discipline_id" id="discipline_id" class="form-control" onblur="completar();">
          <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <option value="<?php echo e($discipline->id); ?>"><?php echo e($discipline->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </select>
      </div>

      <div class="">
  AQUI DEBEN IR LOS DOCUMENTOS COMO CHECKBOXES
</div>

<div class="form-group">
  <label for="document_id">Documents</label>
<table>
  <tr class="row">
    <td class="row col-xs-8">
          <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

       <input type="checkbox" name="document_id" id="document_id" value="<?php echo e($document->id); ?>" class="checkbox-lg" > <?php echo e($document->full_number); ?> - <?php echo e($document->title); ?>

<br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</td>
  </tr>
</table>
</div>

      <div class="form-group">
        <input type="submit" name="Enviar" class="btn btn-primary">
      </div>

    </form>

    <?php endif; ?>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>