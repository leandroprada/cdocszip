<?php $transmittals = App\Transmittal::all(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php if(!Auth::check()): ?>
    <div class="alert alert-danger" role="alert">
        <h2 class="alert-heading">Please login</h2>
        <h4 >Some features require being logged in to the system.</h4>
        </div>
        <?php else: ?>
        <div class="row">
          <div class="col-md-8">
            <table class="table">
              <thead><tr>
                <th>Row</th>
                <th>Number</th>
                <th>Title</th>
                <th>Discipline</th>
                <th>Project</th>
                    </tr>
                </thead>
           <tbody>
             <?php  $i=1;
              ?>
         <?php $__currentLoopData = $transmittals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmittal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
         <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($transmittal->number); ?></td>
            <td><?php echo e($transmittal->title); ?></td>
            <td><?php echo e($transmittal->discipline_id); ?></td>
            <td><?php echo e($transmittal->project_ID); ?></td>
            <td><a href="#">LINK A ESTE TRANSMITTAL</a></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tr>

        </tbody>
         </table>



      </div>


    </div>


  </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<!-- <?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.js"></script>
<?php $__env->stopSection(); ?> -->

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>