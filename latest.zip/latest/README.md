# c-documents
## Synopsis
This project is a CRM solution for document control in SMEs.
Built on Laravel.
## Motivation
There are numerous SMEs which do not have a simple solution to carry out their DC system.
## Installation
Just clone the directory
## Contributors
So far, Just me. Leo Prada
## License
A short snippet describing the license (MIT, Apache, etc.)
